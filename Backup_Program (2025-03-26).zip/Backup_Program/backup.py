from datetime import datetime
import backupcfg
import pathlib
from pathlib import Path
import shutil
import sys

import logging
logging.basicConfig(filename=backupcfg.LogFileLocation(), level = logging.DEBUG) 
logger=logging.getLogger()


current_datetime = datetime.now().strftime('%Y%m%d-%H%M%S')

#This is the location of the source file
if len(sys.argv) <= 1:
    src_file = backupcfg.SourceFile()
else:
    src_file = backupcfg.JobSourceFiles()

if Path(src_file).exists() != True:
    print("The source file could not be found.")
    quit()

#Convert it using the class PurePath and extract the name of the file
src_loc = pathlib.PurePath(src_file)
src_name = src_loc.name

#This is the location of the destination directory

dst_dir =""
dst_loc =""

# if "job01" in sys.argv:
#     print("Job 1")

try:
    dst_dir = backupcfg.DestinationFolder()
except Exception as err:
    print("error for dst_dir")
    logger.error(err)
    
try:
    #Combine the location of the destionation directory with the source filename and the current datetime to create the path of the backup job
    dst_loc = dst_dir + "/" + "backuptext" + "_" + current_datetime
except Exception as err:
    print("error for dist_loc")
    logger.error(err)

try:
    #Fully copy the source file to the destination, only changing the name to append the datetime of operation
    print("src_loc : ", src_loc)
    print("dst_loc : ", dst_loc)
    shutil.copy2(src_loc, dst_loc)
    logger.info("Success")
except Exception as err:
    print("eror for copy:", err)
    logger.error(err)
    logger.fo()


