# Config file for 'backup.py'

job1_source_file = "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/test_files/text.txt"
job2_source_file = "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/test_files/foldertest"
job3_source_file = "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/test_files/testpython.py"
    
destination_folder = "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/backups"
    
log_file_location = "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/backup.log"

email_apikey = ""
email_secretkey = ""