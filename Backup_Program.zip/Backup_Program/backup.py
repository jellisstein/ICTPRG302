# backup.py version 1.0 by Jareth Ellis-Stein at 30027143@students.sunitafe.edu.au
# MIT License Copyright (c) 2025 [See the License file for more details]

# Use this script through 'python3 backup.py' to backup any files you want to keep safe
# You can also use the command line arguments 'job1', 'job2' and so on to specify which files to backup
# Use the config file to change which file each 'job' will backup, and where the backup files will end up



# Import relevant modules to be used by the program
from datetime import datetime   # Reads the current date & time at startup
import pathlib                  # Checks file locations and extracts file information
import shutil                   # Fully backup any files and directories
import smtplib                  # Sends log information to an email address

import backupcfg                # Config file; grabs user-modified variables
# 'sys' is imported by the config file to read command line arguments

import logging                  # Logger; writes backup info, including errors, to the log file
logging.basicConfig(filename=backupcfg.LogFileLocation(), level = logging.DEBUG) 
logger=logging.getLogger()



# Note the current date & time
current_datetime = datetime.now().strftime('%Y%m%d-%H%M%S')
# Grab details from the config for sending emails
smtp = backupcfg.EmailDetails()

# Define what happens 
def SendEmail(message):
    # Compile the message with the error found and any relevant information to the backup attempt
    # This includes the error message itself, where the source file and backup destination is, and the datetime of program run
    email = "To: " + smtp["recipient"] + "\n" + "From: " + smtp["sender"] + "\n" + "Subject: Backup Results Log\n\n" + "An error has occured with the backup.py program, please see below for details:" + "\n" + message + "\n" + 25*"~" + "\n" + "Backup target: " + source_file + "\n" + "Backup destination: " + destination_dir + "\n" + "Time & date of attempted backup: " + current_datetime + "\n"
    try:
        # Attempt to send the email
        smtp_server = smtplib.SMTP(smtp["server"],smtp["port"])
        smtp_server.ehlo()
        smtp_server.starttls()
        smtp_server.ehlo()
        smtp_server.login(smtp["user"], smtp["password"])
        smtp_server.sendmail(smtp["sender"], smtp["recipient"], email)
        smtp_server.close()
    except Exception as err:
        print("Error: An error with the email has occured:", err)
        logger.error(err)



# This is the location of the source
source_file = backupcfg.SourceFiles()
# This is the location of the destination directory
destination_dir = backupcfg.DestinationFolder()

# If the config file returns that the CLI argument is not supported, log it as an error
if source_file == "Invalid CLI Argument: No source file defined":
    err = current_datetime + " [FAILED] TypeError - The argument entered into the command line is not supported."
    print(err)
    logger.error(err)
    SendEmail(err)
    quit()
# If the config file returns that there are too many CLI arguments, log it as an error
elif source_file == "Invalid CLI Argument: Too many arguments":
    err = current_datetime + " [FAILED] TypeError - Too many arguments in the command line. This script only supports one argument at a time."
    print(err)
    logger.error(err)
    SendEmail(err)
    quit()

# Test if the source can be found; if not, return an error
if pathlib.Path(source_file).exists() == False:
    err = current_datetime + " [FAILED] FileNotFoundError - The source could not be found: '" + str(source_file) + "'"
    print(err)
    logger.error(err)
    SendEmail(err)
    quit()
    
# Test if the destionation directory can be found; if not, return an error
if pathlib.Path(destination_dir).exists() == False:
    err = current_datetime + " [FAILED] FileNotFoundError - The backup folder could not be found: '" + str(destination_dir) + "'"
    print(err)
    logger.error(err)
    SendEmail(err)
    quit()

# Convert the source location using the PurePath class
source_loc = pathlib.PurePath(source_file)

# If the source is a directory, copy the full name and leave the filetype variable blank
if pathlib.Path(source_loc).is_dir():
    source_name = source_loc.name
    source_type = ""
# If the source is a file, extract the name and filetype seperately to allow appending only the file name
else:
    source_name = source_loc.stem
    source_type = source_loc.suffix


# Create the final location of the file to be backed up
# This will also grab the source name and append it with the current datetime
destination_loc = destination_dir + "/" + source_name + "_backup_" + current_datetime + source_type

# Print the source location and the backup destination into the terminal to show the user
print("Source location :", source_loc)
print("Destination location :", destination_loc)

# Finally, attempt to fully copy the source into the destination
try:
    if pathlib.Path(source_loc).is_dir():
        shutil.copytree(source_loc, destination_loc)
    else:
        shutil.copy2(source_loc, destination_loc)
    print("[SUCCESS] The file has sucessfully been backed up at " + current_datetime)
    success_info = current_datetime + " [SUCCESS] '" + str(source_loc) + "' has been backed up succesfully to '" + str(destination_loc) + "'"
    logger.info(success_info)
except Exception as err:
    fail_info = current_datetime + " [FAILED] An error with the backup process has occured: " + str(err)
    print(fail_info)
    logger.error(fail_info)
    SendEmail(fail_info)