# Config file for 'backup.py'
import sys

def SourceFiles():
    # This will let the program know if there are too many arguments in the command line
    if len(sys.argv) >= 2:
        return "Invalid CLI Argument: Too many arguments"
    
    # This is the default source file to backup, if no arguments were specified in terminal OR if 'job1' was specified 
    elif "job1" in sys.argv or len(sys.argv) <= 1:
        # Default = "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/test_files/text.txt"
        return "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/test_files/text.txt"
        
    elif "job2" in sys.argv:
        # Default = "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/test_files/foldertest"
        return "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/test_files/foldertest"
        
    elif "job3" in sys.argv:
        # Default = "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/test_files/testpython.py"
        return "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/test_files/testpython.py"
    
    # This will let the program know if the command line argument inputted by the user is invalid
    else:
        return "Invalid CLI Argument: No source file defined"


def DestinationFolder():
    # Default = "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/backups"
    return "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/backups"
    
    
def LogFileLocation():
    # Default = "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/backup.log"
    return "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/backup.log"

    
def EmailDetails():
    apikey = "dd3e028f3beac83d8ace214e5effbd87"
    secretkey = "e253e3297381c2bb4556a36d9f60ea35"
    
    return {
        "sender": "30027143@students.sunitafe.edu.au",
        "recipient": "jwellis.stein@gmail.com",
        "server": "in-v3.mailjet.com",
        "port": 587,
        "user": apikey,
        "password": secretkey}