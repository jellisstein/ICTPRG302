# Config file for 'backup.py'
import sys

def SourceFiles():
    if len(sys.argv) >= 2:
        return "Invalid CLI Argument: Too many arguments"
    
    #This is the default source file to backup, if no arguments were specified in terminal OR if 'job1' was specified 
    elif "job1" in sys.argv or len(sys.argv) <= 1:
        # Default = "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/text.txt"
        return "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/test_files/text.txt"
        
    elif "job2" in sys.argv:
        return "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/test_files/foldertest"
        
    elif "job3" in sys.argv:
        return "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/test_files/testpython.py"
        
    else:
        #The config file will return False if an argument inputted into the CLI is not supported
        return "Invalid CLI Argument: No source file defined"


def DestinationFolder():
    # Default = "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/backups"
    return "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/backups"
    
    
def LogFileLocation():
    # Default = "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/backup.log"
    return "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/backup.log"
    
def EmailDetails():
    apikey = ""
    secretkey = ""
    
    return {
        "sender": "",
        "recipient": "",
        "server": "",
        "port": 587,
        "user": apikey,
        "password": secretkey}