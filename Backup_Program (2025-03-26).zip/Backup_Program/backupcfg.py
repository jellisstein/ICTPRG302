# Config file for 'backup.py'
import sys

def SourceFile():
    # Default = "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/test.txt"
    return "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/test.txt"
    
def JobSourceFiles():
    if "job01" in sys.argv:
        return "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/test.txt"
    if "job02" in sys.argv:
        return "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/cat.txt"

def DestinationFolder():
    # Default = "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/backups"
    return "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/backups"
    
def LogFileLocation():
    # Default = "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/backup.log"
    return "/home/ec2-user/environment/ICTPRG302Assessment/Backup_Program/backup.log"